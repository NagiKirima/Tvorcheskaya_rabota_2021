#include "solvew.h"
#include "ui_solvew.h"
#include <QPainter>
#include <QGridLayout>
#include <QPushButton>
#include "glwidget.h"


SolveW::SolveW(QWidget *parent) : QWidget(parent), ui(new Ui::SolveW)
{
    ui->setupUi(this);
    //setAttribute(Qt::WA_DeleteOnClose);
    GLWidget *Scene = new GLWidget(this); //opengl widget
    ui->GridGraphic->addWidget(Scene);
}

SolveW::~SolveW()
{
   delete ui;
   //emit closemainwindow();
}
