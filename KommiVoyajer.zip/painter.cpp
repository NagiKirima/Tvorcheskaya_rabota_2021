#include "painter.h"
#include <QPaintEvent>
#include <QPainter>
#include <QWidget>
#include <QtCore/qmath.h>
#include <cmath>
#include <vector>
#include <map>
#include <iterator>
#include <fstream>
#include <algorithm>
#include <string>

int R = 300;
int r = 30;
int HText = 35;
double PI = 3.1415;
int xo = 400, yo = 400;
int kol = 0;
const int M = INT_MAX;
QColor green(0,255,0);

std::vector<std::vector<int>> grafMatrix;
std::vector<std::vector<int>> copyMatrix;
std::vector<std::pair<int,int>> listofWAYS; //from,to
std::vector<int> ways; //for draw
std::vector<QColor> colors = {Qt::green, Qt::blue, Qt::yellow, Qt::red, QColor(165,110,255), QColor(110,25,226), QColor(233,255,110), QColor(135,255,147)};

// algorithm of branches and borders part
void reductionRow()
{
    int size = kol;
    for(int i = 0; i < size; i++)
    {
        int min = M; // min in i-row
        //find min in row
        for(int j = 0; j < size; j++)
        {
            if(copyMatrix[i][j] < min && copyMatrix[i][j] != -1)
                min = copyMatrix[i][j];
        }

        if(min != M && min != 0)
        {
            for(int j = 0; j < size; j++)
            {
                if(copyMatrix[i][j] > 0 && copyMatrix[i][j] != M)
                    copyMatrix[i][j] -= min;
            }
        }
    }
}
void reductionCol()
{
    int size = kol;
    for(int i = 0; i < size; i++)
    {
        int min = M; // min in i-col
        for(int j = 0; j < size; j++)
        {
            if(copyMatrix[j][i] < min && copyMatrix[j][i] != -1)
                min = copyMatrix[j][i];
        }

        if(min != M && min != 0)
        {
            for(int j = 0; j < size; j++)
            {
                if(copyMatrix[j][i] > 0 && copyMatrix[j][i] != M)
                    copyMatrix[j][i] -= min;
            }
        }
    }
}
int FindMinInLine(int h, int g)
{
    //int min = copyMatrix[h][0];
    int min = M;
    for(int i = 0; i < kol; i++)
    {
        if(copyMatrix[h][i] < min && i != g && copyMatrix[h][i] != -1)
            min = copyMatrix[h][i];
    }
    return min;
}
int FindMinInCol(int h, int g)
{
    //int min = copyMatrix[0][g];
    int min = M;
    for(int i = 0; i < kol; i++)
    {
        if(copyMatrix[i][g] < min && i != h && copyMatrix[i][g] != -1)
            min = copyMatrix[i][g];
    }
    return min;
}
std::pair<int,int> FindWay()
{
    int max = -M;
    int size = kol;
    std::vector<std::vector<int>> cop = copyMatrix;
    std::pair<int,int> way;
    for(int i = 0; i < size; i++)
    {
        for(int j = 0; j < size; j++)
        {
            if( copyMatrix[i][j] == 0 )//&& grafMatrix[j][i] != 0)
            {
                int mark = FindMinInLine(i,j) + FindMinInCol(i,j);
                if(max < mark)
                {
                    max = mark;
                    way.first = i;
                    way.second = j;
                }
            }
        }
    }
    //clearing the return way
    if(copyMatrix[way.second][way.first] == 0)
        copyMatrix[way.second][way.first] = -1;

    //clearing row and col of finded way
    for(int i = 0; i < size; i++)
    {
        copyMatrix[way.first][i] = -1;
        copyMatrix[i][way.second] = -1;
    }
    return way;
}
void Algorithm()
{
    copyMatrix = grafMatrix;
    for(int i = 0; i < kol; i++)
        for(int j = 0; j < kol; j++)
        {
            if(i == j)
                copyMatrix[i][j] = -1;
            if(copyMatrix[i][j] <= 0)
                copyMatrix[i][j] = -1;
        }

    int iter = 0;
    while(iter != kol)
    {
        reductionRow();
        reductionCol();
        std::pair<int,int> tmp;
        tmp = FindWay();
        if(tmp != std::pair<int,int>(0,0))
            listofWAYS.push_back(tmp);
        iter++;
    }
}

//find optimal way part
int FindNode(int value, int &to, int end)
{
    for(int i = 0; i < listofWAYS.size(); i++)
    {
        if(listofWAYS[i].first == value)
        {
            if(listofWAYS[i].second == end)
            {
                to = listofWAYS[i].second;
                return 2;
            }
            to = listofWAYS[i].second;
            return 1;
        }
    }
    return 0;
}
int FindNode(int value, int &to)
{
    for(int i = 0; i < listofWAYS.size(); i++)
    {
        if(listofWAYS[i].first == value)
        {
            to = listofWAYS[i].second;
            return 1;
        }
    }
    return 0;
}
std::vector<int> OptimizedWay(int first)
{
    std::vector<int> result;
    if(listofWAYS.size() < kol)
        return result;

    int check = 1;
    int copyfirst = first;
    result.push_back(copyfirst);
    check = FindNode(copyfirst, copyfirst);
    while(check == 1)
    {
         result.push_back(copyfirst);
         check = FindNode(copyfirst, copyfirst, first);
    }
    result.push_back(copyfirst);
    if(check == 0)
        result.clear();
    return result;
}


//answer func part
int GetLenght(std::vector<int> buffer)
{
    int result = 0;
    for(int i = 0; i < buffer.size() - 1; i++)
    {
        result += grafMatrix[buffer[i]][buffer[i+1]];
    }
    return result;
}
std::string GetAnswer(std::vector<int> buffer)
{
    std::vector<std::pair<int,int>> a = listofWAYS;
    if(listofWAYS.size() < kol)
        return "No answer";

    std::string answer = "Answer:";
    for (int i = 0; i < buffer.size(); i++)
    {
        if(i == buffer.size() - 1)
            answer = answer + std::to_string(buffer[i] + 1);
        else
            answer = answer + std::to_string(buffer[i] + 1) + "->";
    }
    answer += "=" + std::to_string(GetLenght(buffer));
    return answer;
}

Painter::Painter()
{
    back = QBrush(QColor(252, 177, 177));
    textPen = QPen(QColor(0, 0, 0));
}

//work with file part
bool StringToNums(std::string buffer, std::vector<int> &listofnums)
{
    if( buffer == "")
        return false;

    QString tmp;
    int i = 0;
    while(buffer[i] != '\0')
    {
        if(buffer[i] != ',')
        {
            tmp.push_back(buffer[i]);
            i++;
        }
        else
        {
            listofnums.push_back(tmp.toInt());
            i++;
            tmp.clear();
        }
    }
    listofnums.push_back(tmp.toInt());

    while(listofnums.size() < kol)
        listofnums.push_back(0);
    if(listofnums.size() > kol)
        listofnums.erase(listofnums.begin() + kol, listofnums.end());
    return true;
}
void Read()
{
    std::string name = "Matrix.txt";
    std::ifstream read;
    read.open(name);
    while(!read.eof())
    {
        std::string buffer;
        read >> buffer;
        std::vector<int> tmp;
        bool check = StringToNums(buffer,tmp);
        if(check)
        {
            grafMatrix.push_back(tmp);
        }
    }
    read.close();
}
void GetMatrixSize()
{
    std::string name = "Matrix.txt";
    std::ifstream input;
    input.open(name);
    while(!input.eof())
    {
        std::string tmp;
        input >> tmp;
        if(tmp != "")
            kol++;
    }
}
void ReadWays()
{
    std::string name = "Ways.txt";
    std::ifstream read;
    read.open(name);
    while(!read.eof())
    {
        std::string tmp;
        read >> tmp;
        if(tmp != "")
            ways.push_back(stoi(tmp));
    }
    read.close();
}
//paint
void Painter::calc(QPainter *painter, QPaintEvent *event)
{
    GetMatrixSize(); // get grafMatrix size with using file Matrix.txt
    Read(); //read file "Matrix.txt"
    ReadWays(); //read file "Ways.txt"
    if(grafMatrix.size() == 0)
    {
        grafMatrix = {{0, 14, 0, 0, 0, 0},
                      {0, 0, 0, 0, 42, 23},
                      {19, 0, 0, 9, 0, 0},
                      {0, 0, 0, 0, 0, 31},
                      {0, 0, 18, 0, 0, 0},
                      {28, 23, 0, 0, 0, 0}};

        /*grafMatrix = {{0, 20, 18, 12, 8},
                      {5, 0, 14, 7, 11},
                      {12, 18, 0, 6, 11},
                      {11, 17, 11, 0, 12},
                      {5, 5, 5, 5, 0}};*/
    }
     kol = grafMatrix.size();

     //checking ways
     bool check_ways = true;
     if(ways.empty())
         check_ways = false;
     if(!ways.empty() && (ways[0] > kol || ways[0] < 1))
     {
         ways.clear();
         check_ways = false;
     }

     //getting answer
     std::vector<int> optimizedway;
     std::string answer;
     if(check_ways)
     {
         Algorithm(); //methods of branches and paths
         optimizedway = OptimizedWay(ways[0] - 1);
    }
     answer = GetAnswer(optimizedway);

     //-------------------------------//
     srand(time(0));
     painter->setPen(textPen);
     textPen.setWidth(2);
     painter->fillRect(event->rect(), back);
     //-------------------------------//

     //draw-calculate part
     std::vector<QColor> colorsbuffer;
     for (int i = 0; i < kol; i++)
     {
         // nodes
         double a = PI / 2 + PI * 2 / kol * i; // angle of i-node
         int x1 = xo + cos(a) * R, y1 = yo + sin(a) * R; // node coord
         QString NodeNumber; NodeNumber.setNum(i + 1);
         QColor randomizecolor(rand() % 220 + 36, rand() % 220 + 36, rand() % 220 + 36);
         colorsbuffer.push_back(randomizecolor);
         painter->setBrush(randomizecolor);
         //painter->setBrush(colors[i]);
         painter->drawEllipse(QRectF(x1 - r, y1 - r, 2 * r, 2 * r)); // shifting the upper-left angle by a radius
         Font.setPixelSize(HText);
         painter->setFont(Font);
         painter->drawText(QRect(x1 - HText / 2, y1 - HText/2 , HText, HText), Qt::AlignCenter, NodeNumber);

         for(int j = 0; j < kol; j++)
         {
             if(grafMatrix[i][j] > 0 && i!=j)
             {
                  // lines
                  //calculation
                  double b = PI / 2 + 2*PI / kol * j;
                  double xline = xo + cos(b) * R, yline = yo + sin(b) * R;
                  double linelenght = sqrt(pow(xline-x1, 2) + pow(yline-y1,2));
                  int xl1 = x1 + (xline - x1) / linelenght * r;
                  int yl1 = y1 + (yline - y1) / linelenght * r;
                  int xl2 = xline - (xline - x1) / linelenght * r;
                  int yl2 = yline - (yline-y1) / linelenght * r;

                  //draw line
                  painter->drawLine(xl1, yl1, xl2, yl2);

                  // len of path
                  int xtext = xl2 + (xl1 - xl2) / 6 - r;
                  int ytext = yl2 + (yl1 - yl2) / 6 - r;
                  Font.setPixelSize(25);
                  painter->setFont(Font);
                  painter->drawText(QRect(xtext, ytext, HText, HText), Qt::AlignCenter, QString::number(grafMatrix[i][j]));
             }
          }
     }

     //draw rect with colorsbuffer using
     for(int i = 0; i < kol; i++)
     {
         double a = PI / 2 + PI * 2 / kol * i; // angle of i-node
         int x1 = xo + cos(a) * R, y1 = yo + sin(a) * R;
         painter->setBrush(colorsbuffer[i]);
         for(int j = 0; j < kol; j++)
         {
             if(grafMatrix[i][j] > 0 && i!=j)
             {

                 double b = PI / 2 + 2*PI / kol * j;
                 double xline = xo + cos(b) * R, yline = yo + sin(b) * R;
                 double linelenght = sqrt(pow(xline-x1, 2) + pow(yline-y1,2));
                 int xl1 = x1 + (xline - x1) / linelenght * r;
                 int yl1 = y1 + (yline - y1) / linelenght * r;
                 int xl2 = xline - (xline - x1) / linelenght * r;
                 int yl2 = yline - (yline-y1) / linelenght * r;

                 if(yl1 == yl2)
                 {
                     if(xl2 > xl1)
                         painter->drawRect(xl2 - 12, yl2 - 6, 12, 12);
                     else
                         painter->drawRect(xl2, yl2 - 6, 12, 12);
                 }
                 else if(yl2 > yl1)
                 {
                     if(xl2 > xl1)
                         painter->drawRect(xl2 - 12, yl2 - 12, 12, 12);
                     else
                     {
                         if(xl1 == xl2)
                             painter->drawRect(xl2 - 6, yl2 - 12, 12, 12);
                         else
                             painter->drawRect(xl2, yl2 - 12, 12, 12);
                     }
                 }
                 else if(yl2 < yl1)
                 {
                     if(xl2 > xl1)
                         painter->drawRect(xl2 - 12, yl2, 12, 12);
                     else
                     {
                         if(xl1 == xl2)
                             painter->drawRect(xl2 - 6, yl2, 12, 12);
                         else
                             painter->drawRect(xl2, yl2, 12, 12);
                     }
                 }
             }
         }
     }

     //answer on widthcenter of window
     QString ans = QString::fromStdString(answer);
     Font.setPixelSize(HText);
     painter->setFont(Font);
     painter->drawText(QRect(xo - 20 * ans.size(), 0, 40 * ans.size(), 2 * HText), Qt::AlignHCenter, ans);

     grafMatrix.clear();
     listofWAYS.clear();
     ways.clear();

}
