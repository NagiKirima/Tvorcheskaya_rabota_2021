#ifndef SOLVEW_H
#define SOLVEW_H

#include <QWidget>

namespace Ui {
class SolveW;
}

class SolveW : public QWidget
{
    Q_OBJECT

public:
    explicit SolveW(QWidget *parent = nullptr);
    ~SolveW();
signals:
    void closemainwindow();
private:
    Ui::SolveW *ui;
};

#endif // SOLVEW_H
