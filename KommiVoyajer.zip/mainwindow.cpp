#include "mainwindow.h"
#include "ui_mainwindow.h"
MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    solve = new SolveW(); // init second window
    connect(ui->pushButton_solve, &QPushButton::clicked, this, &MainWindow::solve_clicked);
    connect(solve, &SolveW::closemainwindow, this, &MainWindow::close);
}
MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    delete solve;
    QApplication::quit();
}
void ClearString(std::string &buffer)
{
    std::string alph = {'0','1','2','3','4','5','6','7','8','9',',','-'};
    for(int i = 0; i < buffer.size();)
    {
        if(alph.find(buffer[i]) == std::string::npos )
            buffer.erase(buffer.begin() + i);
        else
            i++;
    }
}


void MainWindow::solve_clicked()
{
    std::string name = "Matrix.txt";
    std::ofstream read;
    read.open(name);
    std::string tmp = ui->textEdit_1->toPlainText().toStdString();
    ClearString(tmp);
    if(tmp != "")
        read << tmp << std::endl;

    tmp = ui->textEdit_2->toPlainText().toStdString();
    ClearString(tmp);
    if(tmp != "")
        read << tmp << std::endl;

    tmp = ui->textEdit_3->toPlainText().toStdString();
    ClearString(tmp);
    if(tmp != "")
        read << tmp << std::endl;

    tmp = ui->textEdit_4->toPlainText().toStdString();
    ClearString(tmp);
    if(tmp != "")
        read << tmp << std::endl;

    tmp = ui->textEdit_5->toPlainText().toStdString();
    ClearString(tmp);
    if(tmp != "")
        read << tmp << std::endl;

    tmp = ui->textEdit_6->toPlainText().toStdString();
    ClearString(tmp);
    if(tmp != "")
        read << tmp << std::endl;

    tmp = ui->textEdit_7->toPlainText().toStdString();
    ClearString(tmp);
    if(tmp != "")
        read << tmp << std::endl;

    tmp = ui->textEdit_8->toPlainText().toStdString();
    ClearString(tmp);
    if(tmp != "")
        read << tmp << std::endl;
    read.close();

    name = "Ways.txt";
    read.open(name);
    tmp = ui->textEdit_9->toPlainText().toStdString();
    ClearString(tmp);
    if(tmp != "")
        read << tmp << std::endl;

    solve->show();
}



