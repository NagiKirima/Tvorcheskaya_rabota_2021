#include "glwidget.h"
#include "painter.h"
#include <QPainter>
GLWidget::GLWidget(QWidget *parent) : QOpenGLWidget(parent)
{
    Scene = new Painter;
}
void GLWidget::paintEvent(QPaintEvent *event)
{
    QPainter qpainter;
    qpainter.begin(this);
    Scene->calc(&qpainter, event);
    qpainter.end();
    this->update();
}
