#ifndef GLWIDGET_H
#define GLWIDGET_H
#include "painter.h"
#include <QOpenGLWidget>


class GLWidget : public QOpenGLWidget
{
    Q_OBJECT
public:
    GLWidget( QWidget *parent);
protected:
    void paintEvent(QPaintEvent *event) override;
private:
    Painter *Scene;
};
#endif // GLWIDGET_H
