#ifndef PAINTER_H
#define PAINTER_H
#include <QBrush>
#include <QFont>
#include <QPen>
#include <QWidget>
#include "mainwindow.h"

class Painter
{
public:
    Painter();
    void calc(QPainter *painter, QPaintEvent *event);
    QBrush front;
    QBrush back;
    QFont Font;
    QPen textPen;
};

#endif // PAINTER_H
