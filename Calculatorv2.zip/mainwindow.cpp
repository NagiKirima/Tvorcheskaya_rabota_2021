 #include "mainwindow.h"
#include "ui_mainwindow.h"

QString prevNUM;
int counter = 0;
bool flag = false;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Calculator");
    //connect char-buttons
    connect(ui->pushButton_0, &QPushButton::clicked, this, &MainWindow::numbers);
    connect(ui->pushButton_1, &QPushButton::clicked, this, &MainWindow::numbers);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &MainWindow::numbers);
    connect(ui->pushButton_3, &QPushButton::clicked, this, &MainWindow::numbers);
    connect(ui->pushButton_4, &QPushButton::clicked, this, &MainWindow::numbers);
    connect(ui->pushButton_5, &QPushButton::clicked, this, &MainWindow::numbers);
    connect(ui->pushButton_6, &QPushButton::clicked, this, &MainWindow::numbers);
    connect(ui->pushButton_7, &QPushButton::clicked, this, &MainWindow::numbers);
    connect(ui->pushButton_8, &QPushButton::clicked, this, &MainWindow::numbers);
    connect(ui->pushButton_9, &QPushButton::clicked, this, &MainWindow::numbers);
    connect(ui->pushButton_dot, &QPushButton::clicked, this, &MainWindow::numbers);
   //clear, % and multmin btn
    connect(ui->pushButton_clear, &QPushButton::clicked, this, &MainWindow::operations);
    connect(ui->pushButton_multminus, &QPushButton::clicked, this, &MainWindow::operations);
    connect(ui->pushButton_proc, &QPushButton::clicked, this, &MainWindow::operations);

    //calc operations
    connect(ui->pushButton_plus, &QPushButton::clicked, this, &MainWindow::calc);
    connect(ui->pushButton_minus, &QPushButton::clicked, this, &MainWindow::calc);
    connect(ui->pushButton_mult, &QPushButton::clicked, this, &MainWindow::calc);
    connect(ui->pushButton_div, &QPushButton::clicked, this, &MainWindow::calc);

    //calc btn
    connect(ui->pushButton_calc, &QPushButton::clicked, this, &MainWindow::equal);

    //for 2-operands func
    ui->pushButton_plus->setCheckable(true);
    ui->pushButton_minus->setCheckable(true);
    ui->pushButton_div->setCheckable(true);
    ui->pushButton_mult->setCheckable(true);
    ui->pushButton_calc->setCheckable(false);

    //for time-calcs part
    ui->pushButton_TIMEON->setCheckable(true);
    connect(ui->pushButton_TIMEON, &QPushButton::clicked, this, &MainWindow::time);
    connect(ui->pushButton_2DOTS, &QPushButton::clicked, this, &MainWindow::time);
    connect(ui->pushButton_SEC, &QPushButton::clicked, this, &MainWindow::time_calc);
    connect(ui->pushButton_MIN, &QPushButton::clicked, this, &MainWindow::time_calc);
    connect(ui->pushButton_HOURS, &QPushButton::clicked, this, &MainWindow::time_calc);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::numbers()
{
    QPushButton *currentBTN = (QPushButton*) sender(); //to know what a btn
    QString tmp;

    if(ui->resultShow->text() == "ERROR")
        ui->resultShow->setText("");

    if(ui->resultShow->text() == "Hour:Min:Sec")
        ui->resultShow->setText("0");

    if(ui->resultShow->text() == "0" && currentBTN->text() != ".")
        ui->resultShow->setText("");

    QString buffer = ui->resultShow->text();
    bool checkdot = false;
    for(int i =0; i < buffer.size(); i++)
    {
        if(buffer[i] == ".")
            checkdot = true;
    }

    if(flag) //checking flag for timecalc
        checkdot = true;

    if(checkdot != true && currentBTN->text() == ".")
    {
        tmp = ui->resultShow->text() + currentBTN->text();
        ui->resultShow->setText(tmp);
    }
    else if(currentBTN->text() != ".")
    {
        tmp = ui->resultShow->text() + currentBTN->text();
        ui->resultShow->setText(tmp);
    }

}
void MainWindow::operations()
{
    QPushButton *currentBTN = (QPushButton*) sender();
    if(currentBTN->text() == "*(-)" && ui->pushButton_TIMEON->isChecked() != true)
    {
        QString tmp = ui->resultShow->text();
        double num = tmp.toDouble();
        tmp = QString::number(num*(-1));
        ui->resultShow->setText(tmp);
    }
    else if(currentBTN->text() == "AC")
    {
        ui->pushButton_plus->setChecked(false);
        ui->pushButton_minus->setChecked(false);
        ui->pushButton_div->setChecked(false);
        ui->pushButton_mult->setChecked(false);
        ui->pushButton_TIMEON->setChecked(false);
        ui->resultShow->setText("0");
        flag = false;
        counter = 0;
    }
    else if (ui->pushButton_TIMEON->isChecked() != true && currentBTN->text() == "%")
    {
        double tmp = ui->resultShow->text().toDouble();
        QString tmp2 = QString::number(tmp/100);
        ui->resultShow->setText(tmp2);
    }
}
void MainWindow::calc()
{
     QPushButton *currentBTN = (QPushButton*) sender();

     if(ui->pushButton_TIMEON->isChecked() == true && currentBTN->text()!= "+"
             &&  currentBTN->text()!= "-" && currentBTN->text()!= "AC") //&& currentBTN->text()!= "=")
     {
          currentBTN->setChecked(false);
     }
     else
     {
         if(ui->pushButton_div->isChecked() == true || ui->pushButton_plus->isChecked() == true || ui->pushButton_minus->isChecked() == true || ui->pushButton_mult->isChecked() == true )
         {
             if(ui->resultShow->text() != "0")
                 prevNUM = ui->resultShow->text();

             ui->pushButton_div->setChecked(false);
             ui->pushButton_plus->setChecked(false);
             ui->pushButton_minus->setChecked(false);
             ui->pushButton_mult->setChecked(false);
             currentBTN->setChecked(true);
             ui->resultShow->setText("0");
             counter = 0;
         }
         else
         {
             prevNUM = ui->resultShow->text();
             currentBTN->setChecked(true);
             ui->resultShow->setText("0");
             counter = 0;
         }
     }

}
void MainWindow::equal()
{
    QString currentNUM = ui->resultShow->text();
    //convert string to Time object part
    Time prev, current;
    if(flag == true)
    {
        int cntr = 0;
        QString h; QString m; QString s;
        for(int i = 0; i < prevNUM.length(); i++)
        {
            if(prevNUM[i] == ':')
            {
                cntr++;
                i++;
            }
            if(cntr == 0)
                h+=prevNUM[i];
            if(cntr == 1)
                m+=prevNUM[i];
            if(cntr == 2)
                s+=prevNUM[i];
        }
        prev.SetH(h.toInt());
        prev.SetM(m.toInt());
        prev.SetS(s.toInt());
        h.clear(); m.clear(); s.clear();

        cntr = 0;
        for(int i = 0; i < currentNUM.length(); i++)
        {
            if(currentNUM[i] == ':')
            {
                cntr++;
                i++;
            }
            if(cntr == 0)
                h+=currentNUM[i];
            if(cntr == 1)
                m+=currentNUM[i];
            if(cntr == 2)
                s+=currentNUM[i];
        }
        current.SetH(h.toInt());
        current.SetM(m.toInt());
        current.SetS(s.toInt());
    }
    //=====================================//
    if(ui->pushButton_mult->isChecked() == true)
    {
        double tmp = currentNUM.toDouble() * prevNUM.toDouble();
        QString str = QString::number(tmp);
        ui->resultShow->setText(str);
        ui->pushButton_mult->setChecked(false);
    }
    else if(ui->pushButton_div->isChecked() == true)
    {
        if(currentNUM.toDouble() == 0)
            ui->resultShow->setText("ERROR");
        else
        {
            if(prevNUM.toDouble() == 0)
            {
                ui->resultShow->setText("0");
                ui->pushButton_mult->setChecked(false);
            }
            else
            {
                double tmp = prevNUM.toDouble() / currentNUM.toDouble();
                QString str = QString::number(tmp);
                ui->resultShow->setText(str);
                ui->pushButton_mult->setChecked(false);
            }
        }
        ui->pushButton_div->setChecked(false);
    }
    else if(ui->pushButton_plus->isChecked() == true)
    {
        if(flag == true)
        {
            prev = prev + current;
            QString ans = QString::number(prev.GetH()) + ":" +  QString::number(prev.GetM()) + ":" +  QString::number(prev.GetS());
            ui->resultShow->setText(ans);
            ui->pushButton_plus->setChecked(false);
            //flag = false;
        }
        else
        {
            double tmp = currentNUM.toDouble() + prevNUM.toDouble();
            QString str = QString::number(tmp);
            ui->resultShow->setText(str);
            ui->pushButton_plus->setChecked(false);
        }
    }
    else if(ui->pushButton_minus->isChecked() == true)
    {
        if(flag == true)
        {
            prev = prev - current;
            QString ans = QString::number(prev.GetH()) + ":" +  QString::number(prev.GetM()) + ":" +  QString::number(prev.GetS());
            ui->resultShow->setText(ans);
            ui->pushButton_minus->setChecked(false);
            //flag = false;
        }
        else
        {
            double tmp =  prevNUM.toDouble() - currentNUM.toDouble();
            QString str = QString::number(tmp);
            ui->resultShow->setText(str);
            ui->pushButton_minus->setChecked(false);
        }
    }
}


void MainWindow::time()
{
     QPushButton *currentBTN = (QPushButton*) sender();
     if(currentBTN->text() == "TIME CALC")
     {
         ui->pushButton_TIMEON->setChecked(true);
         flag = true;
         counter = 0;
         ui->resultShow->setText("Hour:Min:Sec");
     }
     else if (currentBTN->text() == ":" && flag == true)
     {
         if(counter < 2)
         {
             if(ui->resultShow->text() != "Hour:Min:Sec")
             {
                 counter++;
                 QString tmp = ui->resultShow->text() + ui->pushButton_2DOTS->text();
                 ui->resultShow->setText(tmp);
             }
         }
         else
         {
             counter = 0;
             ui->resultShow->setText("Hour:Min:Sec");
         }
     }
}
void MainWindow::time_calc()
{
    QPushButton *currentBTN = (QPushButton*) sender();
    QString value = ui->resultShow->text();
    int cntr = 0;
    QString h; QString m; QString s;
    for(int i = 0; i < value.length(); i++)
    {
        if(value[i] == ':')
        {
            cntr++;
            i++;
        }
        if(cntr == 0)
            h+=value[i];
        if(cntr == 1)
            m+=value[i];
        if(cntr == 2)
            s+=value[i];
    }

    if(currentBTN->text() == "SEC"  && flag)//&& counter == 2)
    {
        Time c(h.toInt(), m.toInt(), s.toInt());
        h = QString::number(c.toSec());
        ui->resultShow->setText(h);
        counter = 0;
        ui->pushButton_TIMEON->setChecked(false);
        flag = false;
    }
    else if(currentBTN->text() == "MIN" &&  flag)//counter == 2)
    {
        Time c(h.toInt(), m.toInt(), s.toInt());
        h = QString::number(c.toMin());
        ui->resultShow->setText(h);
        counter = 0;
        ui->pushButton_TIMEON->setChecked(false);
        flag = false;
    }
    else if (currentBTN->text() == "HOURS" && flag)//&& counter == 2)
    {
        Time c(h.toInt(), m.toInt(), s.toInt());
        h = QString::number(c.toHours());
        ui->resultShow->setText(h);
        counter = 0;
        ui->pushButton_TIMEON->setChecked(false);
        flag = false;
    }
}
