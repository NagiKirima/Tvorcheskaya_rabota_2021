#ifndef TIME_H
#define TIME_H
class Time
{
private:
    int _hours;
    int _minutes;
    int _seconds;
public:
    Time();
    Time(int h, int m, int s);
    int toSec();
    double toMin();
    double toHours();
    void SetH(int value);
    void SetM(int value);
    void SetS(int value);
    int GetH();
    int GetM();
    int GetS();
    Time& operator-(Time &b);
    Time& operator+(Time &b);
    Time& operator=(Time &b);
    bool operator > (Time b);
};
#endif // TIME_H
