#include "TIME.h"
#include <math.h>
Time::Time()
{
    _hours = 0;
    _minutes = 0;
    _seconds = 0;
}
Time::Time(int h, int m, int s)
{
    _hours = h;
    _minutes = m;
    _seconds = s;
    if(abs(_seconds) >= 60)
    {
        _minutes += _seconds / 60;
        _seconds = _seconds % 60;
    }
    if(abs(_minutes) >= 60)
    {
        _hours += _minutes / 60;
        _minutes = _minutes % 60;
    }
}
int Time::toSec()
{
    return _hours * 3600 + _minutes * 60 + _seconds;
}
double Time::toMin()
{
    return _hours * 60 + _minutes + double(_seconds) / 60;
}
double Time::toHours()
{
    return _hours + double(_minutes) / 60 + double(_seconds) / 3600;
}
Time& Time::operator+(Time &b)
{
    int otv = this->toSec() + b.toSec();
    Time c;
    int h, m, s;
    h = otv / 3600;
    m = (otv - (h * 3600)) / 60;
    s = (otv - (h * 3600) - (m * 60));
    c.SetH(h);
    c.SetM(m);
    c.SetS(s);
    return c;
}
Time& Time::operator-(Time &b)
{
    int otv = this->toSec() - b.toSec();
    Time c;
    int h, m, s;
    h = otv / 3600;
    m = (otv - (h * 3600)) / 60;
    s = (otv - (h * 3600) - (m * 60));
    c.SetH(h);
    c.SetM(m);
    c.SetS(s);
    return c;
}
Time& Time::operator=(Time &b)
{
    if (this == &b)
        return *this;
    _hours = b._hours;
    _minutes = b._minutes;
    _seconds = b._seconds;
    return *this;
}
bool Time::operator>(Time b)
{
    return this->toSec() > b.toSec();
}
int Time::GetH(){return _hours;}
int Time::GetM(){return _minutes;}
int Time::GetS(){return _seconds;}

void Time::SetH(int value){_hours = value;}
void Time::SetM(int value){_minutes = value;}
void Time::SetS(int value){_seconds = value;}
